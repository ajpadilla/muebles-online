<?php

return [
	'DB_HOST' => 'localhost',
	'DB_USERNAME' => 'nightzpy_muebles',
	'DB_PASSWORD' => 'muebles',
	'DB_NAME' => 'nightzpy_muebles',
];