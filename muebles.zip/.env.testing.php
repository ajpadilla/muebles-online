<?php

return [
	'DB_HOST' => 'localhost',
	'DB_USERNAME' => 'root',
	'DB_PASSWORD' => 'root',
	'DB_NAME' => 'muebles_test',
];