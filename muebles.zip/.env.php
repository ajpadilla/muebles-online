<?php

return [
	'DB_HOST' => 'localhost',
	//'DB_USERNAME' => 'nightzpy_muebles',
	'DB_USERNAME' => 'grupo2',
	//'DB_PASSWORD' => 'muebles',
	'DB_PASSWORD' => 'lCkx#038',
	//'DB_NAME' => 'nightzpy_muebles',
	'DB_NAME' => 'grupo2_net',
	'SYSTEM_EMAIL' => 'web@grupo2.net',
	'SYSTEM_EMAIL_NAME' => 'Grupo Dos S.L.',
];