<li class="widget-container widget_tag_cloud">
    <h3 class="widget-title">Tags</h3>
    <div class="tagcloud">
        <a href="#">aside</a>
        <a href="#">audio</a>
        <a href="#">blog</a>
        <a href="#">design</a>
        <a href="#">gallery</a>
        <a href="#">image</a>
        <a href="#">link</a>
        <a href="#">quote</a>
        <a href="#">video</a>
    </div>
    <div class="clear"></div>
</li>