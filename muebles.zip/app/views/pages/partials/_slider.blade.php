<!-- SLIDER -->
<div id="outerslider">
    <div class="container">
        <div id="slidercontainer">
          <section id="slider">
            <div id="slidernivo" class="nivoSlider">
                <img src="{{asset('images/content2/slide1.jpg')}}" alt="slide1" data-thumb="{{asset('images/content//slide1.jpg')}}" title="#22" />
                <img src="{{asset('images/content2/slide2.jpg')}}" alt="slide2" data-thumb="{{asset('images/content//slide2.jpg')}}" title="#21" />
                <img src="{{asset('images/content2/slide3.jpg')}}" alt="slide3" data-thumb="{{asset('images/content//slide3.jpg')}}" title="#20" />
            </div>
            <div id="22" class="nivo-html-caption">
                <div class="slider-title">The Real Paradise in Sight</div>
                <p class="slider-desc">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aenean vitae enim vel eros volutpat vulputate. Proin rutrum eros<br> arcisrtu. Morbi consectetur tellus a tellus mollis quis ornare.</p>
            </div>
            <div id="21" class="nivo-html-caption">
                <div class="slider-title">Luxury &#038; Oriental Harmony</div>
                <p class="slider-desc">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aenean vitae enim vel eros volutpat vulputate. Proin rutrum eros<br> arcisrtu. Morbi consectetur tellus a tellus mollis quis ornare.</p>
            </div>
            <div id="20" class="nivo-html-caption">
                <div class="slider-title">Very Comfortable Hotel's Room</div>
                <p class="slider-desc">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aenean vitae enim vel eros volutpat vulputate. Proin rutrum eros<br> arcisrtu. Morbi consectetur tellus a tellus mollis quis ornare.</p>
            </div>
        </section>
    </div>
</div>
</div>
<div id="outerafterheader">
    <div class="container">
        <div class="row">
            <div class="twelve columns" id="afterheader"></div>
        </div>
    </div>
</div>
<!-- END SLIDER -->