<?php

use Illuminate\Database\Migrations\Migration;

class CabinetSetupUploadsTable extends Migration {

    /**
     * Run the migrations.
     *
     * @return  void
     */
    public function up()
    {
        // Creates the photos table
        Schema::create('photos', function($table)
        {
            $table->increments('id');
            $table->string('filename');
            $table->string('path');
	        $table->string('complete_path');
	        $table->string('complete_thumbnail_path');
            $table->integer('size');
            $table->string('extension', 3);
            $table->string('mimetype', 32);
            $table->integer('user_id')->unsigned()->index();
            $table->integer('product_id')->unsigned()->index(); // If this is a child file, it'll be referenced here.
            $table->softDeletes();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return  void
     */
    public function down()
    {
        Schema::drop('photos');
    }

}
